/*  Canon Electronics Scanner Driver for Linux Version 1.00
 *  Copyright CANON ELECTRONICS INC. 2009
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#ifndef __CANON_DR__
#define __CANON_DR__

#define DEFAULT_VENDOR "Canon"

/* configure file name */
#ifndef CFG_FILE_NAME
#define CFG_FILE_NAME "canondr.conf"
#endif
/* communication module name */
#ifndef COMM_MODULE
#define COMM_MODULE "canondr_com_usb.1.1.0"
#endif
/* default backend name */
#ifndef BACKEND_MODULE
#define BACKEND_MODULE "canondr_backend"
#endif

#endif
