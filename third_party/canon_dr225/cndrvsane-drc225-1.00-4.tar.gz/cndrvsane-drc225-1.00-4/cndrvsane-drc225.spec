# -*- coding:utf-8-unix -*-
#

%define INSTALLDIR /opt/Canon
%define TMP_INSTALLDIR /opt/Canon/DRC225
%define SANELIBDIR /usr/lib64/sane
%define SANECONFDIR /etc/sane.d
%define UDEVRULESDIR /etc/udev/rules.d
%define V_MAJOR 1
%define V_MINOR 00
%define VERSION %{V_MAJOR}.%{V_MINOR}
%define RELEASE 4
%define MYMAKEFLAGS V_MAJOR=%{V_MAJOR} V_MINOR=%{V_MINOR} BUILD=%{RELEASE}
%define _docdir %{_datadir}/doc

%define BACKEND canondr_backenddrc225
%define MODELCONF DRC225.conf

Name: cndrvsane-drc225
Version: %{VERSION}
Release: %{RELEASE}
License: See the COPYING/LICENSE file in each package. 
Group: System Environment/Daemons
Vendor:  CANON ELECTRONICS INC.
Summary: SANE backend for Canon Electronics Scanner Series
Requires: sane-backends >= 1.0.14

BuildRequires: libusb-devel >= 0.1.8
BuildRequires: automake >= 1.9.2
BuildRequires: libtool >= 1.5.6

BuildRoot: %{_tmppath}/%{name}-%{version}
Source0: %{name}-%{version}-%{release}.tar.gz
Source1: sane-backends-1.0.19.tar.gz

%description
SANE backend for Canon Electronics Scanner Series
DRC225

%prep
%setup -qc -a 1

%build
(cd sane-backends-1.0.19;./configure --prefix=/usr --sysconfdir=/etc;make)
(cd %{name}-%{version}-%{release};autoreconf -i;./configure --prefix=%{INSTALLDIR};make %{MYMAKEFLAGS})

%install
mkdir -p ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/etc/sane.d/canondr
mkdir -p ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/etc/udev/rules.d
mkdir -p ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/lib/canondr
mkdir -p ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/lib/sane
mkdir -p ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/share/doc/%{name}

cd %{name}-%{version}-%{release}

cp -f ./bin/%{BACKEND} ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/lib/canondr/%{BACKEND}
cp -f ./configs/%{MODELCONF} ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF}
cp -f ./configs/canondr.conf ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/etc/sane.d/canondr.conf
cp -f ./configs/80-cndrvsane.rules ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/etc/udev/rules.d/80-cndrvsane.rules
cp -f ./src/canondr_com_usb ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0
cp -f ./src/.libs/libsane-canondr.so.1.0.0 ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0
cp -f ./COPYING ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/share/doc/%{name}/COPYING
cp -f ./README ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/share/doc/%{name}/README
cp -f ./LICENSE-drc225-1.00E.txt ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/share/doc/%{name}/LICENSE-drc225-1.00E.txt
cp -f ./LICENSE-drc225-1.00J.txt ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/share/doc/%{name}/LICENSE-drc225-1.00J.txt
cp -f ./README-drc225-1.00.txt ${RPM_BUILD_ROOT}%{TMP_INSTALLDIR}/share/doc/%{name}/README-drc225-1.00.txt

%clean
rm -rf $RPM_BUILD_ROOT

%post
mkdir -p %{INSTALLDIR}/etc/sane.d/canondr
mkdir -p %{INSTALLDIR}/lib/canondr
mkdir -p %{INSTALLDIR}/lib/sane

#**********install BACKEND***************#
if [ -e %{INSTALLDIR}/lib/canondr/%{BACKEND} ]
then
	rm -f %{INSTALLDIR}/lib/canondr/%{BACKEND}
fi

cp -f %{TMP_INSTALLDIR}/lib/canondr/%{BACKEND} %{INSTALLDIR}/lib/canondr/%{BACKEND}

#*********install config files************#
if [ -e %{INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF} ]
then
	rm -f %{INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF}
fi
cp -f %{TMP_INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF} %{INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF}

if [ -e %{INSTALLDIR}/etc/sane.d/canondr.conf ]
then
	(if grep -q "\sDRC225$" %{INSTALLDIR}/etc/sane.d/canondr.conf;then :;  \
	else cat %{TMP_INSTALLDIR}/etc/sane.d/canondr.conf >> %{INSTALLDIR}/etc/sane.d/canondr.conf; fi)
else
	cp -f %{TMP_INSTALLDIR}/etc/sane.d/canondr.conf %{INSTALLDIR}/etc/sane.d/canondr.conf
	ln -sf %{INSTALLDIR}/etc/sane.d/canondr.conf %{SANECONFDIR}/

	CONFILE=%{SANECONFDIR}/dll.conf
	if [ -n "`grep '#[[:space:]]*canondr' ${CONFILE}`" ];then
   	sed -i 's,#[[:space:]]*\(canondr\),\1,' ${CONFILE}
	elif [ -z "`grep canondr ${CONFILE}`" ];then
   	echo canondr >> ${CONFILE}
	fi
		
fi

#*********install rule file************#
if [ -e %{UDEVRULESDIR}/80-cndrvsane.rules ]
then
	(if grep -q "^\/\/DRC225$" %{UDEVRULESDIR}/80-cndrvsane.rules;then :;  \
	else cp -f %{TMP_INSTALLDIR}/etc/udev/rules.d/80-cndrvsane.rules %{UDEVRULESDIR}/80-cndrvsane.rules; fi)
else
	cp -f %{TMP_INSTALLDIR}/etc/udev/rules.d/80-cndrvsane.rules %{UDEVRULESDIR}/80-cndrvsane.rules
fi


#*************install binary files************#
if [ -e %{INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0 ]
then
	rm -f %{INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0
fi
cp -f %{TMP_INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0 %{INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0
chmod 4755 %{INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0

if [ -e %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 ]
then
	rm -f %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0
	cp -f %{TMP_INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0
else
	cp -f %{TMP_INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0
	ln -sf %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 %{SANELIBDIR}/
	ln -sf %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 %{SANELIBDIR}/libsane-canondr.so.1
	ln -sf %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 %{SANELIBDIR}/libsane-canondr.so
fi

#*************install documents******************#
rm -rf %{_docdir}/%{name}*
mkdir -p %{_docdir}/%{name}

cp -f %{TMP_INSTALLDIR}/share/doc/%{name}/* %{_docdir}/%{name}

exit 0

%preun

#*****************uninstall BACKEND*****************#
if [ -e %{INSTALLDIR}/lib/canondr/%{BACKEND} ]
then
	rm -f %{INSTALLDIR}/lib/canondr/%{BACKEND}
fi

#******************uninstall config files************#
if [ -e %{INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF} ]
then
	rm -f %{INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF}
fi

if [ -e %{INSTALLDIR}/etc/sane.d/canondr.conf ]
then
	cat %{INSTALLDIR}/etc/sane.d/canondr.conf|awk '$3=="DRC225"{print NR}'>tmp.txt
	read  START < tmp.txt
	if [ $? -eq 0 ]
	then		
		cat %{INSTALLDIR}/etc/sane.d/canondr.conf|sed "$START, +3 d" > out.txt
		cp -f out.txt %{INSTALLDIR}/etc/sane.d/canondr.conf
		rm -f tmp.txt out.txt
	fi
fi

LINE=`cat %{INSTALLDIR}/etc/sane.d/canondr.conf|wc -l`
if [ $LINE -lt 4 ]
then
	rm -f %{INSTALLDIR}/etc/sane.d/canondr.conf
	rm -f %{SANECONFDIR}/canondr.conf
		
	CONFFILE=%{SANECONFDIR}/dll.conf
   if [ -n "`grep ^canondr ${CONFFILE}`" ];then
		sed -i 's/^canondr/#canondr/' ${CONFFILE}
   fi
fi

#******************uninstall rule files************#
if [ ! -e %{INSTALLDIR}/etc/sane.d/canondr.conf ]
then
	if [ -e %{UDEVRULESDIR}/80-cndrvsane.rules ]
	then
		rm -f %{UDEVRULESDIR}/80-cndrvsane.rules
	fi
fi

#******************uninstall binary files************#
if [ ! -e %{INSTALLDIR}/etc/sane.d/canondr.conf ]
then
	if [ -e %{INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0 ]
	then
		rm -f %{INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0
	fi

	if [ -e %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0 ]
	then
		rm -f %{INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0
		rm -f %{SANELIBDIR}/libsane-canondr.so
		rm -f %{SANELIBDIR}/libsane-canondr.so.1
		rm -f %{SANELIBDIR}/libsane-canondr.so.1.0.0
	fi
fi

#*****************remove documents*********************#
rm -rf %{_docdir}/%{name}*

exit 0

%postun

#******************romove install directory************#
if [ ! -e %{INSTALLDIR}/etc/sane.d/canondr.conf ]
then
	rm -rf %{INSTALLDIR}
fi

exit 0

%files
%defattr(-,root,root)
%{TMP_INSTALLDIR}/lib/canondr/%{BACKEND}
%{TMP_INSTALLDIR}/etc/sane.d/canondr/%{MODELCONF}
%{TMP_INSTALLDIR}/etc/sane.d/canondr.conf
%{TMP_INSTALLDIR}/etc/udev/rules.d/80-cndrvsane.rules
%{TMP_INSTALLDIR}/lib/canondr/canondr_com_usb.1.1.0
%{TMP_INSTALLDIR}/lib/sane/libsane-canondr.so.1.0.0
%{TMP_INSTALLDIR}/share/doc/%{name}/COPYING
%{TMP_INSTALLDIR}/share/doc/%{name}/README
%{TMP_INSTALLDIR}/share/doc/%{name}/LICENSE-drc225-1.00E.txt
%{TMP_INSTALLDIR}/share/doc/%{name}/LICENSE-drc225-1.00J.txt
%{TMP_INSTALLDIR}/share/doc/%{name}/README-drc225-1.00.txt

