#!/bin/sh
if [ -n $1 ]
then
INSTALLDIR=/opt/Canon
else
INSTALLDIR=$1
fi
SANECONFDIR=/etc/sane.d
UDEVRULESDIR=/etc/udev/rules.d


if [ -e $INSTALLDIR/etc/sane.d/canondr/DRC225.conf ]
then
	rm -f $INSTALLDIR/etc/sane.d/canondr/DRC225.conf
fi

if [ -e $INSTALLDIR/etc/sane.d/canondr.conf ]
then
	cat $INSTALLDIR/etc/sane.d/canondr.conf|awk '$3=="DRC225"{print NR}'>tmp.txt
	read  START < tmp.txt
	if [ $? -eq 0 ]
	then
		cat $INSTALLDIR/etc/sane.d/canondr.conf|sed "$START, +3 d" > out.txt
		cp -f out.txt $INSTALLDIR/etc/sane.d/canondr.conf
		rm -f tmp.txt out.txt
	fi
fi

LINE=`cat $INSTALLDIR/etc/sane.d/canondr.conf|wc -l`
if [ $LINE -lt 4 ]
then
	rm -f $INSTALLDIR/etc/sane.d/canondr.conf
	rm -f $SANECONFDIR/canondr.conf
	
	CONFFILE=$SANECONFDIR/dll.conf
   if [ -n "`grep ^canondr $CONFFILE`" ];then
		sed -i 's/^canondr/#canondr/' $CONFFILE
   fi

fi

if [ ! -e $INSTALLDIR/etc/sane.d/canondr.conf ]
then
	if [ -e $UDEVRULESDIR/80-cndrvsane.rules ]
	then
		rm -f $UDEVRULESDIR/80-cndrvsane.rules
	fi
fi


